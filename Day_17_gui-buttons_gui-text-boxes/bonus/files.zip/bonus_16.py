import PySimpleGUI as sg

label1 = sg.Text("Select the file to compress:")
inpu1 = sg.Input()
button1 = sg.FileBrowse("Choose", key="files")

label2 = sg.Text("Select the destination folder:")
input2 = sg.Input()
button2 = sg.FolderBrowse("Choose", key="folder")

compress_button = sg.Button("Compress")

window = sg.Window("Compress", layout=[[label1, inpu1, button1],
                                       [label2, input2, button2],
                                       [compress_button]])
while True:
    event, values = window.read()
    print(event, values)
    filepath = values["files"].split(";")
    folder = values["folder"]



window.close()

